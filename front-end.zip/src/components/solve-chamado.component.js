import React, { Component } from 'react'
import ChamadoDataService from "../services/chamado.service"
import AuthService from "../services/auth.service"
import {Link} from 'react-router-dom'
import * as moment from 'moment'

export default class Atender extends Component {
    constructor(props) {
        super(props)

        this.buscaChamado = this.buscaChamado.bind(this)
        this.estadoNome = this.estadoNome.bind(this)
        this.estadoUnidade = this.estadoUnidade.bind(this)
        this.estadoDescricao = this.estadoDescricao.bind(this)
        this.estadoRamal = this.estadoRamal.bind(this)
        this.estadoSetor = this.estadoSetor.bind(this)
        this.estadoArea = this.estadoArea.bind(this)
        this.estadoSelectArea = this.estadoSelectArea.bind(this)
        this.estadoResponsavel = this.estadoResponsavel.bind(this)
        this.estadoSolucao = this.estadoSolucao.bind(this)
        this.estadoStatus = this.estadoStatus.bind(this)
        this.estadoSelectStatus = this.estadoSelectStatus.bind(this)
        this.estadoDtPrevisao = this.estadoDtPrevisao.bind(this)
        this.estadoDtPrevisaoNovo = this.estadoDtPrevisaoNovo.bind(this)
        this.estadoDtFechamento = this.estadoDtFechamento.bind(this)
        this.estadoDtFechamentoNovo = this.estadoDtFechamentoNovo.bind(this)

        this.salvarChamado = this.salvarChamado.bind(this)
        

        this.state = {
            current: {
                id: null,
                nome: "",
                username: "",
                dt_abertura: "",
                unidade: "",
                descricao: "",
                ramal: "",
                setor: "",
                area: "",
                selectedArea: "",
                responsavel: "",
                solucao: "",
                dt_previsao: "",
                dt_previsao_novo: "",
                dt_fechamento: "",
                dt_fechamento_novo: "",
                foto: "",
                imagem: "",
                url:"",
                status: "",
                selectedStatus: "",
                situacao: false
            },
            currentUser: AuthService.getCurrentUser(),
            message: ""           
        }
    }

    componentDidMount() {
        this.buscaChamado(this.props.match.params.id)
    }

    buscaChamado(id) {
        ChamadoDataService.buscarUm(id)
            .then(response => {
                this.setState({
                    current: {
                        id: response.data.id,
                        nome: response.data.nome,
                        dt_abertura: moment(response.data.dt_abertura).format('DD/MM/YYYY'),
                        username: response.data.username,
                        unidade: response.data.unidade,
                        ramal: response.data.ramal,
                        setor: response.data.setor,
                        descricao: response.data.descricao,
                        area: response.data.area,
                        responsavel: response.data.responsavel,
                        solucao: response.data.solucao,
                        dt_previsao: moment(response.data.dt_previsao).format('DD/MM/YYYY'),
                        dt_fechamento: moment(response.data.dt_fechamento).format('DD/MM/YYYY'),
                        status: response.data.status,
                        foto: response.data.foto,
                        situacao: response.data.situacao                     
                    }
                })
            })
            .catch(e => {
                console.log(e)
            })    
    }


    estadoUpload(e) {
        //Verifica se o usuário escolheu e depois cancelou a escolha do arquivo. Assim a imagem volta a ser a padrão
        if(!e.target.files[0]){
            const imagem = {name: "default.jpg", type: "image/jpeg"}
            const foto = "default.jpg"
            const url = ""
            this.setState({
                imagem: imagem,
                url: url,
                foto: foto
            })
        }
        //Quando o usuário escolhe uma imagem a ser enviada
        else {
            const imagem = e.target.files[0]
            this.setState({
                imagem: imagem,
                url: URL.createObjectURL(imagem)          
            })
        }
    }

    estadoNome(e) {
        const nome = e.target.value
        this.setState(prevState => ({
            current: {
                ...prevState.current,
                 nome: nome
            }
        }))
    }

    estadoUnidade(e) {
        const unidade = e.target.value
        this.setState(prevState => ({
            current: {
                ...prevState.current,
                 unidade: unidade
            }
        }))
    }

    estadoRamal(e) {
        const ramal = e.target.value
        this.setState(prevState => ({
            current: {
                ...prevState.current,
                 ramal: ramal
            }
        }))
    }

    estadoDescricao(e) {
        const descricao = e.target.value
        this.setState(prevState => ({
            current: {
                ...prevState.current,
                 descricao: descricao
            }
        }))
    }

    estadoSetor(e) {
        const setor = e.target.value
        this.setState(prevState => ({
            current: {
                ...prevState.current,
                 setor: setor
            }
        }))
    }

    estadoArea(e) {
        const area = e.target.value
        this.setState(prevState => ({
            current: {
                ...prevState.current,
                 area: area
            }
        }))
    }

    estadoSelectArea(e) {
        const selectedArea = e.target.value
        this.setState(prevState => ({
            current: {
                ...prevState.current,
                 area: selectedArea
            }
        }))
    }

    estadoResponsavel(e) {
        const responsavel = e.target.value
        this.setState(prevState => ({
            current: {
                ...prevState.current,
                 responsavel: responsavel
            }
        }))
    }

    estadoSolucao(e) {
        const solucao = e.target.value
        this.setState(prevState => ({
            current: {
                ...prevState.current,
                 solucao: solucao
            }
        }))
    }

    estadoStatus(e) {
        const status = e.target.value
        this.setState(prevState => ({
            current: {
                ...prevState.current,
                 status: status
            }
        }))
    }

    estadoSelectStatus(e) {
        const selectedStatus = e.target.value
        this.setState(prevState => ({
            current: {
                ...prevState.current,
                 status: selectedStatus
            }
        }))
    }

    estadoDtPrevisao(e) {
        const dt_previsao = e.target.value
        this.setState(prevState => ({
            current: {
                ...prevState.current,
                dt_previsao: dt_previsao
            }
        }))
    }

    estadoDtPrevisaoNovo(e) {
        const dt_previsao_novo = e.target.value
        this.setState(prevState => ({
            current: {
                ...prevState.current,
                dt_previsao: dt_previsao_novo
            }
        }))
    }

    estadoDtFechamento(e) {
        const dt_fechamento = e.target.value
        this.setState(prevState => ({
            current: {
                ...prevState.current,
                dt_fechamento: dt_fechamento
            }
        }))
    }

    estadoDtFechamentoNovo(e) {
        const dt_fechamento_novo = e.target.value
        this.setState(prevState => ({
            current: {
                ...prevState.current,
                dt_fechamento: dt_fechamento_novo
            }
        }))
    }

   salvarImagem() {
    
        if(this.state.foto === "default.jpg") {
            this.salvarChamado()  
            return false
        } if(this.state.foto !== "default.jpg") {
        
            var data = new FormData()
            data.append('file', this.state.imagem)
        
            ChamadoDataService.cadastrarImagem(data)
            .then(response => {
                this.setState({
                    foto: response.data.foto
                })
                this.salvarChamado()
            })
            .catch(e => {
                console.log(e)
            })
        }
    }

    salvarChamado() {

        var data = {
            nome: this.state.current.nome,
            unidade: this.state.current.unidade,
            ramal: this.state.current.ramal,
            setor: this.state.current.setor,
            area: this.state.current.area,
            descricao: this.state.current.descricao,
            responsavel: this.state.current.responsavel,
            solucao: this.state.current.solucao,
            dt_previsao: moment(this.state.current.dt_previsao, 'DD-MM-YYYY'),
            dt_fechamento: moment(this.state.current.dt_fechamento, 'DD-MM-YYYY'),
            foto: this.state.current.foto,
            status: this.state.current.status
        }

        ChamadoDataService.editar(this.state.current.id ,data)
                .then(response => {
                    this.setState({
                        id: response.data.id,
                        nome: response.data.nome,
                        username: response.data.username,
                        dt_abertura: response.data.dt_abertura,
                        unidade: response.data.unidade,
                        ramal: response.data.ramal,
                        setor: response.data.setor,
                        area: response.data.area,
                        descricao: response.data.descricao,
                        foto: response.data.foto,
                        status: response.data.status,
                        solucao: response.data.solucao,
                        responsavel: response.data.responsavel, 
                        dt_previsao: response.data.dt_previsao,
                        dt_fechamento: response.data.dt_fechamento,
                        situacao: response.data.situacao,
                        submitted: true
                    })                    
                })
                .catch(e => {
                    console.log(e)
                })
    }  



    render() {

        const { current } = this.state

        let agendado = null
        if (current.status === "Agendado") {
            agendado = <div className="form-group">
                <label htmlFor="agendado">Previsão</label>
                <input type="text" className="form-control" value={current.dt_previsao} onChange={this.estadoDtPrevisaoNovo} />
            </div>
        }

        let finalizado = null
        if (current.status === "Finalizado") {
            finalizado = <div className="form-group">
                <label htmlFor="finalizado">Finalizado em: </label>
                <input type="text" className="form-control" value={current.dt_fechamento} onChange={this.estadoDtFechamentoNovo} />
            </div>
        }
        let solucao = null
        if (current.status === "Finalizado") {
           solucao =  
           <div className="form-group">
                <label htmlFor="solucao"> Solução </label>
                <textarea required                
                type="memo" 
                className="form-control" 
                id="solucao"                                             
                value={current.solucao} 
                onChange={this.estadoSolucao} 
                name="solucao" />
            </div>
            if (current.solucao === "" || current.solucao === undefined) {
                alert ("Uma solução deve ser digitada!")                
            }
        }

        return(
            <div className="submit-form">
                { this.state.submitted ? (
                    <div>
                        <h4> Chamado editado com sucesso!</h4>
                        <Link to={"/admin"} className="btn btn-info" style={{marginLeft: 20+'px', marginBottom: 15+'px'}}> 
                            Voltar
                        </Link>
                    </div>
                ) : (
                
                    <div>

                        <div className="form-group">
                            <label htmlFor="nome"> Nome </label>
                            <input 
                            type="text" 
                            className="form-control" 
                            id="nome"                              
                            value={current.nome} 
                            onChange={this.estadoNome}
                            name="nome" />
                        </div>
                    
                        <div className="form-group">
                            <label htmlFor="unidade"> Unidade </label>
                            <select 
                                className="form-control" 
                                id="unidade" 
                                name="unidade"
                                value={current.unidade}                                                                     
                                onChange={this.estadoUnidade} >                                    
                                <option value="1">Selecione</option>
                                <option value="Caxias">Caxias</option>  
                                <option value="Nilópolis">Nilópolis</option> 
                                <option value="Nova Iguacu"> Nova Iguaçu </option>
                                <option value="Queimados"> Queimados </option>
                                <option value="Rio de Janeiro"> Rio de Janeiro </option>
                                <option value="Vilar dos Teles">Vilar dos Teles</option>
                                <option value="CDRio Nova Iguaçu"> CDRio Nova Iguaçu </option>
                                <option value="CDRio São Gonçalo"> CDRio São Gonçalo </option>
                            </select>
                        </div>

                        <div className="form-group">
                            <label htmlFor="ramal"> Ramal </label>
                            <input 
                            type="number" 
                            className="form-control" 
                            id="ramal"                             
                            value={current.ramal} 
                            onChange={this.estadoRamal} 
                            name="ramal" />
                        </div>

                        <div className="form-group">
                            <label htmlFor="setor"> Setor Solicitante </label>
                            <input 
                            type="text" 
                            className="form-control" 
                            id="setor"                             
                            value={current.setor} 
                            onChange={this.estadoSetor} 
                            name="setor" />
                        </div>

                        <div className="form-group">
                            <label htmlFor="area"> Área Requisitada </label>
                            <select 
                                className="form-control" 
                                id="area" 
                                name="area"                                
                                value={current.area}                                    
                                onChange={this.estadoSelectArea} >                                    
                                <option value="1">Selecione</option>
                                <option value="Alarme/CFTV/Rede/Telefonia"> Alarme/CFTV/Rede/Telefonia </option>
                                <option value="Ar Condicionado"> Ar Condicionado </option>
                                <option value="Compras"> Compras </option>  
                                <option value="Financeiro"> Financeiro </option>  
                                <option value="Gráfica"> Gráfica </option>  
                                <option value="Manutenção"> Manutenção </option> 
                                <option value="Recursos Humanos"> Recursos Humanos </option>                                                                
                                <option value="TI"> TI </option>
                                <option value="Transporte"> Transporte </option>
                            </select>
                        </div>
                    
                        <div className="form-group">
                            <label htmlFor="descricao"> Descrição </label>
                            <input 
                            type="text" 
                            className="form-control" 
                            id="descricao"                             
                            value={current.descricao} 
                            onChange={this.estadoDescricao} 
                            name="descricao" />
                        </div>

                        <div className="form-group">
                            <label htmlFor="status"> Status </label>
                            <select 
                                className="form-control" 
                                id="status" 
                                name="status"                                
                                value={current.status}                                    
                                onChange={this.estadoSelectStatus} >                                 
                                <option value="Pendente"> Pendente </option>
                                <option value="Em análise"> Em análise </option>  
                                <option value="Aprovação Glauber"> Aprovação Glauber </option>  
                                <option value="Agendado"> Agendado </option>  
                                <option value="Em atendimento"> Em atendimento  </option> 
                                <option value="Finalizado"> Finalizado </option>                                
                                <option value="Cancelado"> Cancelado </option>
                                <option value="Aguardando Fornecedor"> Aguardando Fornecedor </option>
                            </select>
                        </div>
                        {agendado}

                        
                        <div className="form-group">
                            <label htmlFor="responsavel"> Responsável </label>
                            <input 
                            type="text" 
                            className="form-control" 
                            id="responsavel"                             
                            value={current.responsavel} 
                            onChange={this.estadoResponsavel} 
                            name="responsavel" />
                        </div>

                        {solucao}
                        {finalizado}
                    
                        <div className="image-container">
                            <div className="upload">
                               
                            </div>

                            <div className="envio">
                                <input 
                                    type="file" 
                                    accept="image/*" 
                                    className="file"
                                    onChange={this.estadoUpload}
                                    id="file"
                                    name="file" /> 
                            </div>
                        </div>
                    
                        <button onClick={this.salvarChamado} className="btn btn-success" style={{marginBottom: 15+'px'}}>
                            Editar
                        </button>

                        <Link to={"/admin"} className="btn btn-info" style={{marginLeft: 20+'px', marginBottom: 15+'px'}}> Voltar</Link>
                        <div style={{display: 'grid'}}>
                            <span> <b>Criado por: </b> {current.username}</span>
                            <span><b>Atendido por: </b>{current.responsavel}</span>
                        </div>
                    </div>
                )}
            </div>
        )
    }



}