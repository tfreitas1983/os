import React, { Component } from 'react'


export default class Chamado extends Component {
   


    render() {

        return(
            <div>
                Editar de chamados
            </div>
        )
    }



}