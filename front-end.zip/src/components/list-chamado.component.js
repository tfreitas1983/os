import React, { Component } from 'react'
import {Link} from 'react-router-dom'
import ChamadoDataService from "../services/chamado.service"
import AuthService from "../services/auth.service"
import * as moment from 'moment'
import {FaEdit, FaEye} from 'react-icons/fa'
import { IconContext } from "react-icons"


export default class ChamadosLista extends Component {
    constructor(props) {
        super(props)

        this.pegaChamados = this.pegaChamados.bind(this)
        this.estadoBuscaNome = this.estadoBuscaNome.bind(this)
        this.estadoBuscaChamado = this.estadoBuscaChamado.bind(this)
        this.estadoBuscaData = this.estadoBuscaData.bind(this)
        this.estadoBuscaArea = this.estadoBuscaArea.bind(this)
        this.estadoBuscaStatus = this.estadoBuscaStatus.bind(this)
        this.buscarNome = this.buscarNome.bind(this)
        this.buscarChamado = this.buscarChamado.bind(this)
        this.buscarData = this.buscarData.bind(this)
        this.buscarArea = this.buscarArea.bind(this)
        this.buscarStatus = this.buscarStatus.bind(this)
        this.toggleFiltro = this.toggleFiltro.bind(this)

        this.state = {
            chamados: [],
            info: {},
            page: 1,
            current: null,
            currentIndex: -1,
            currentUser: AuthService.getCurrentUser(),
            selectedPage: null,
            buscaNome: "",
            buscaChamado: "",
            buscaArea: "",
            buscaStatus: "",
            mostraFiltro: true,
            className: 'hidden'
        }
    }

    componentDidMount() {
        this.pegaChamados()        
    }

    pegaChamados(page = 1) {        
        ChamadoDataService.buscarTodos(page)
            .then(response => {
            //REST do response da API em duas constantes: 
            // "docs" com os dados do chamado e "info" com os dados das páginas
                const { docs, ...info } = response.data 
                this.setState({
                    chamados: docs,
                    info: info,
                    page: page
                })                
            })
            .catch(e => {
                console.log(e)
            })
    }

    ativaChamado(chamado, index) {
        this.setState({
            current: chamado,
            currentIndex: index
        })
    }

    estadoBuscaNome(e) {
        const buscaNome = e.target.value
        this.buscarNome()        
        this.setState({
            buscaNome: buscaNome
        })
    }

    estadoBuscaChamado(e) {
        const buscaChamado = e.target.value
        this.buscarChamado()        
        this.setState({
            buscaChamado: buscaChamado
        })
    }

    estadoBuscaData(e) {
        const buscaData = e.target.value
        this.buscarData()        
        this.setState({
            buscaData: buscaData
        })
    }

    estadoBuscaArea(e) {
        const buscaArea = e.target.value
        this.buscarArea()
        this.setState({
            buscaArea: buscaArea
        })
    }

    estadoBuscaStatus(e) {
        const buscaStatus = e.target.value
        this.buscarStatus()
        this.setState({
            buscaStatus: buscaStatus
        })
    }

    limpaCurrent() {
        this.setState({
            current: null,
            currentIndex: -1,
            selectedPage: null,
            buscaNome: "",
            buscaChamado: "",
            buscaSetor: "",
            buscaArea: "",
            buscaStatus: ""          
        })
    }

    buscarNome(page = 1) {
        ChamadoDataService.buscarNome(this.state.buscaNome, page)
            .then(response => {
                const { docs, ...info } = response.data 
                this.setState({
                    chamados: response.data.docs,
                    info: info                                 
                })    
            })
            .catch(e => {
                console.log(e)
            })
    }

    buscarChamado(page = 1) {
        ChamadoDataService.buscarChamado(this.state.buscaChamado, page)
        .then(response => {
            const { docs, ...info } = response.data 
            this.setState({
                chamados: response.data.docs,
                info: info                                 
            })    
        })
        .catch(e => {
            console.log(e)
        })
    }

    buscarData(page = 1) {
        ChamadoDataService.buscarData(this.state.buscaData, page)
            .then(response => {
                const { docs, ...info } = response.data 
                this.setState({
                    chamados: response.data.docs,
                    info: info                                 
                })    
            })
            .catch(e => {
                console.log(e)
            })
    }

    buscarArea(page = 1) {
        ChamadoDataService.buscarArea(this.state.buscaArea, page)
            .then(response => {
                const { docs, ...info } = response.data 
                this.setState({
                    chamados: response.data.docs,
                    info: info                                 
                })    
            })
            .catch(e => {
                console.log(e)
            })
    }

    buscarStatus(page = 1) {
        ChamadoDataService.buscarStatus(this.state.buscaStatus, page)
            .then(response => {
                const { docs, ...info } = response.data 
                this.setState({
                    chamados: response.data.docs,
                    info: info                                 
                })    
            })
            .catch(e => {
                console.log(e)
            })
    }

    toggleFiltro() {
        this.setState(state=> ({
           mostraFiltro: !state.mostraFiltro
        }))

        if(this.state.mostraFiltro === true) {
            this.setState({
                className: 'show'
            })
        } else {
            this.setState({
                className: 'hidden'
            })
        }
        
    }


    render() {

        const { chamados, current, currentUser, page, info, className,
            buscaNome, buscaChamado, buscaSetor, buscaArea, buscaStatus} = this.state

        let i = 0
        let paginas = []
        for ( i = 1; i <= info.pages; i++ ) {
            paginas.push(
                <li className={"page-item " + (page === i ? "active" : "")} key={i}>
                    <span className="page-link" key={i} id={i} onClick={this.selecionaPagina} >
                        {i}
                    </span>
                </li>
            )            
        } 

        let filtros = null
        if (chamados && (buscaChamado !== "" || buscaChamado !== undefined)) {
            filtros = 
            <div>

            </div>
        }

        let mostrar = null
        if (current !== null) {
            mostrar =  <div className="autocomplete-items-active">
                {current.numchamado}{current.descricao}{current.status}{current.dt_abertura}
                {<Link to={`/chamados/${current.id}`} id="editar" className="autocomplete-items">Editar</Link>}
            </div>
        } 

        let filtro = null
        if (chamados) {
            filtro = chamados.filter((item) => {
                return item.username === currentUser.username
            })   
                 
            mostrar = 
            <div className="list-group">
                <table>
                    <tbody>
                        <tr>
                            <th>Número</th>                            
                            <th>Nome</th>
                            <th>Descrição</th>
                            <th>Área</th>
                            <th>Data</th>
                            <th>Status</th>
                            <th>Ações</th>                            
                        </tr>
                        {filtro.map((chamado, index) => (
                            <tr key={index}>
                                <td>{chamado.numchamado}</td>                                
                                <td>{chamado.nome}</td>
                                <td>{chamado.descricao}</td>
                                <td>{chamado.area}</td>
                                <td>{moment(chamado.dt_abertura).format('DD/MM/YYYY')}</td>
                                <td>{chamado.status}</td>
                                <td>
                                    <IconContext.Provider value={{ size: "2em", className: "global-class-name" }}>
                                        {<Link to={`/chamados/visualizar/${chamado.id}`} id="view"> <FaEye /> </Link>}
                                        {<Link to={`/chamados/editar/${chamado.id}`} id="edit"> <FaEdit /> </Link>}
                                    </IconContext.Provider>
                                </td>                                
                            </tr> 
                        ))}
                </tbody>
            </table>
            </div>
        }

        return(
            <div>
                <h1>
                    Lista de chamados
                </h1>
                <div style={{display: 'flex', justifyContent: 'space-between'}}>
                    <div style={{
                        backgroundColor: '#339b44', 
                        borderRadius: 15+'px', 
                        width: 190+'px', 
                        height: 30+'px', 
                        marginTop: 10+'px'
                        }}>
                        <Link to={`/chamados/adicionar`} 
                            style={{
                                color: '#f2f2f2', 
                                fontSize: 24+'px', 
                                marginLeft: 10+'px', 
                                textDecoration: 'none',     
                                marginTop: 0
                            }} 
                            className="actions" >
                            Novo Chamado
                        </Link>                            
                    </div>
                    <div>
                        <button type="button" onClick={this.toggleFiltro} className="btn btn-info">
                            {this.state.mostraFiltro ?  'Filtros': 'Esconder' }
                        </button>
                    </div>
                </div>
                <div className={className} >
                    <div className="form-group" style={{display: 'flex', justifyContent: 'space-around', marginTop: 15+'px'}}>
                        <input type="text" className="form-control" placeholder="Busque pelo número" onChange={this.estadoBuscaChamado} onKeyUp={this.buscarChamado}/>
                        <input type="text" className="form-control" placeholder="Busque pelo nome" onChange={this.estadoBuscaNome} onKeyUp={this.buscarNome}/>
                        <input type="date" className="form-control" placeholder="Busque pela Data" onChange={this.estadoBuscaData} onMouseOut={this.buscarData} onKeyUp={this.buscarData} />
                        <select 
                            className="form-control" 
                            id="area" 
                            name="area"                        
                            value={buscaArea}                                    
                            onChange={this.estadoBuscaArea}       
                            onMouseOut={this.buscarArea} >                              
                            <option value="1">Filtre por área</option>
                            <option value="Alarme/CFTV/Rede/Telefonia"> Alarme/CFTV/Rede/Telefonia </option>
                            <option value="Ar Condicionado"> Ar Condicionado </option>
                            <option value="Compras"> Compras </option>  
                            <option value="Financeiro"> Financeiro </option>  
                            <option value="Gráfica"> Gráfica </option>  
                            <option value="Manutenção"> Manutenção </option> 
                            <option value="Recursos Humanos"> Recursos Humanos </option>                                                                
                            <option value="TI"> TI </option>
                            <option value="Transporte"> Transporte </option>
                        </select>
                        <select 
                            className="form-control" 
                            id="status" 
                            name="status"                        
                            value={buscaStatus}                                    
                            onChange={this.estadoBuscaStatus} > 
                            <option value="1">Filtre por status</option>                                
                            <option value="Pendente"> Pendente </option>
                            <option value="Em análise"> Em análise </option>  
                            <option value="Aprovação Glauber"> Aprovação Glauber </option>  
                            <option value="Agendado"> Agendado </option>  
                            <option value="Em atendimento"> Em atendimento  </option> 
                            <option value="Finalizado"> Finalizado </option>                                
                            <option value="Cancelado"> Cancelado </option>
                            <option value="Aguardando Fornecedor"> Aguardando Fornecedor </option>
                        </select>
                    </div>       
                </div>     
                {mostrar}
            </div>
        )
    }
}