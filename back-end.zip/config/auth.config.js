module.exports = {
    secret: "chamado-secret-key"
  };