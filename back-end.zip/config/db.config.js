module.exports = {
    url: `mongodb://chamados:${encodeURIComponent('@dmCDR!0')}@chamadosrj.ddns.net:27018/?authSource=chamados`
}