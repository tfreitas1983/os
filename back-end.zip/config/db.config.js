module.exports = {
    url: "mongodb://chamadosrj.ddns.net:27017/chamados"
}