const db = require("../models")
const Chamado = db.chamados
const Files = db.files
const moment = require('moment')

exports.cadastrar = (req, res) => {
    if (!req.body.descricao || !req.body.unidade) {
        res.status(400).send({ message: "A descrição e/ou unidade devem ser preenchidas"})
        return
    }

    const chamado = new Chamado ({
        unidade: req.body.unidade,
        dt_abertura: req.body.dt_abertura,
        ramal: req.body.ramal,
        nome: req.body.nome,
        username: req.body.username,
        setor: req.body.setor,
        area: req.body.area,
        descricao: req.body.descricao,
        status: req.body.status,
        responsavel: req.body.responsavel,
        setor: req.body.setor,
        dt_previsao: req.body.dt_previsao,    
        dt_fechamento: req.body.dt_fechamento,        
        situacao: req.body.situacao ? req.body.situacao: true,
        foto: req.body.foto
    })

    chamado
        .save(chamado)
        .then(data => {
            res.send(data)
        })
        .catch(err => {
            res.status(500).send({
                message: err.message || "Um erro ocorreu ao criar o chamado"
            })
        })
}

exports.buscarTodos = (req,res) => {
    const {page = 1} = req.query;
    const nome = req.query.nome
    const numchamado = req.query.numchamado
    const area = req.query.area
    const status = req.query.status

    var condition = nome ? { nome: { $regex: new RegExp(nome), $options: "i" } } : {}
    var condnumero = numchamado ? { numchamado: numchamado } : {}
    var condArea = area ? {area: area } : {}
    var condStatus = status ? {status: status } : {}

    //Verifica se foi passado a data de abertura do chamado
    let dt_abertura = null
    let dt_final = null
    if(req.query.dt_abertura) {
        dt_abertura = new Date(req.query.dt_abertura)
        dt_final = new Date(moment(dt_abertura).add(1,'days'))
    }

     //Verifica se não possui filtro
     if (!nome && !numchamado && !dt_abertura && !area && !status) {
        var query = Chamado.find().sort({dt_abertura: -1})
    }

    //Verifica se foi passado o nome na busca
    if (nome) {
        var query = Chamado.find(condition)
    }

    //Verifica se foi passado o número do chamado na busca
    if (numchamado) {
        var query = Chamado.find(condnumero)
    }

    //Verifica se foi passada a data de abertura do chamado
    if (dt_abertura) {
        var query = Chamado.find({dt_abertura: {$gte: dt_abertura, $lt: dt_final }})
    } 
    
    if (area) {
        var query = Chamado.find(condArea)
    }

    if (status) {
        var query = Chamado.find(condStatus)
    }
    
    Chamado.paginate(query,{page, limit: 5})
        .then(data => {
            res.send(data)
        })
        .catch(err => {
            res.status(500).send({
            message: err.message || "um erro ocorreu ao buscar os chamados"
        })
    })
}

exports.buscarNumero = (req,res) => {
    const numchamado = req.query.numchamado
    var condnumero = { numchamado: numchamado } 
   
    //Verifica se foi passado o número do chamado na busca
    if (numchamado) {
        var query = Chamado.find(condnumero)
    }  
    
    if (!numchamado) {
        var query = {}
    }
    
    Chamado.find(query)
        .then(data => {
            res.send(data)
        })
        .catch(err => {
            res.status(500).send({
            message: err.message || "um erro ocorreu ao buscar os chamados"
        })
    })
}

exports.buscarUm = (req, res) => {
    const id = req.params.id

    Chamado.findById(id)
        .then(data => {
            if (!data) 
                res.status(404).send({ message: "Não foi encontrado o chamado com o id "+ id })
            else res.send(data)
        })
        .catch(err => {
            res
                .status(500)
                .send({ message: "Erro ao buscar o chamado com o id=" +id })
        })
}

exports.editar = (req, res) => {
    if (!req.body) {
        return res.status(400).send({
            message: "Os dados para edição não podem ficar em branco!"
        })
    }

    const id = req.params.id

    Chamado.findByIdAndUpdate(id, req.body, { useFindAndModify: false })
        .then(data => {
            if (!data) {
                res.status(404).send({
                    message: `Não foi possível encontrar e/ou alterar o chamado com o id=${id}. `
                })
            } else res.send({ message: "Chamado alterado com sucesso" })
        })
        .catch(err => {
            res.status(500).send({
                message: "Erro ao alterar o chamado com o id " + id
            })
        })
}

exports.apagar = (req, res) => {
    const id = req.params.id

    Chamado.findByIdAndRemove(id)
        .then(data => {
            if (!data) {
                res.status(404).send({
                    message: "Não foi possível encontrar e/ou deletar o chamado com o id " + id
                })
            } else {
                res.send({
                    message: "Chamado deletado com sucesso!"
                })
            }
        })
        .catch(err => {
            res.status(500).send({
                message: "Não foi possível deletar o chamado com o id " + id
            })
        })
}

exports.apagarTodos = (req, res) => {
    Chamado.deleteMany({})
        .then(data => {
            res.send({
                message: `${data.deletedCount} chamados foram deletados com sucesso`
            })
        })
        .catch(err => {
            res.status(500).send({
                message: "Ocorreu um erro ao deletar todos os chamados"
            })
        })
}

exports.buscarAtivos = (req, res) => {
    Chamado.find({ situacao: true })
        .then(data => {
            res.send(data)
        })
        .catch(err => {
            res.status(500).send({
                message: err.message || "Um erro ocorreu ao buscar os chamados ativos"
            })
        })
}

exports.buscarImagem = (req, res) => {
    const id = req.params.id

    Files.findById(id)   
        .then(data => {
            res.send(data)
        })
        .catch(err => {
            res.status(500).send({
                message: err.message || "Um erro ocorreu ao buscar a imagem"
            })
        })
}

exports.buscarImagens = (req, res) => {   

    Files.find()   
        .then(data => {
            res.send(data)
        })
        .catch(err => {
            res.status(500).send({
                message: err.message || "Um erro ocorreu ao buscar as imagens"
            })
        })
}



exports.cadastrarImagem = (req, res) => {
    const { originalname: original, filename: foto, size, location: url = "" } = req.file
    if (!foto) {
        res.status(400).send({ message: "A imagem deve ser enviada"})
        return
    }

    const file = new Files ({
       original,
       foto,
       size, 
       url
    })
    file    
        .save(file)
        .then(data => {
            res.send(data)
        })
        .catch(err => {
            res.status(500).send({
                message: err.message || "Um erro ocorreu ao criar a imagem"
            })
        })
}





